import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settle-up',
  templateUrl: './settle-up.component.html',
  styleUrls: ['./settle-up.component.css']
})
export class SettleUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
